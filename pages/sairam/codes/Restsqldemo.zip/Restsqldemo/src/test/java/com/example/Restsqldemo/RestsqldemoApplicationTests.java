package com.example.Restsqldemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestsqldemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
